import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class TaskSchedulerApp extends JFrame {
    private final List<Task> tasks = new ArrayList<>();
    private final DefaultListModel<Task> listModel = new DefaultListModel<>();
    private final JList<Task> taskList = new JList<>(listModel);

    private final JTextField titleField = new JTextField();
    private final JComboBox<String> priorityBox =
            new JComboBox<>(new String[]{"High", "Medium", "Low"});
    private final JTextField deadlineField = new JTextField();
    private final JComboBox<String> filterBox =
            new JComboBox<>(new String[]{"All Tasks", "Today's Tasks", "High Priority", "Pending", "Completed"});

    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
    private final File dataFile = new File("tasks.dat");

    public TaskSchedulerApp() {
        setTitle("Smart Task Scheduler");
        setSize(850, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        buildUI();
        loadTasks();
        refreshTaskList();

        new Timer(30000, e -> checkReminders()).start();
    }

    private void buildUI() {
        JPanel inputPanel = new JPanel(new GridLayout(2, 4, 8, 8));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Task Details"));

        inputPanel.add(new JLabel("Title"));
        inputPanel.add(new JLabel("Priority"));
        inputPanel.add(new JLabel("Deadline"));
        inputPanel.add(new JLabel("Format: dd-MM-yyyy HH:mm"));

        inputPanel.add(titleField);
        inputPanel.add(priorityBox);
        inputPanel.add(deadlineField);
        inputPanel.add(new JLabel("Example: 05-10-2026 18:30"));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton addButton = new JButton("Add Task");
        JButton editButton = new JButton("Edit Selected");
        JButton deleteButton = new JButton("Delete");
        JButton completeButton = new JButton("Mark Complete");
        JButton saveButton = new JButton("Save");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(completeButton);
        buttonPanel.add(saveButton);

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        filterPanel.add(new JLabel("Filter:"));
        filterPanel.add(filterBox);

        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        taskList.setFont(new Font("SansSerif", Font.PLAIN, 15));
        JScrollPane scrollPane = new JScrollPane(taskList);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Tasks (sorted by priority and deadline)"));

        addButton.addActionListener(e -> addTask());
        editButton.addActionListener(e -> editTask());
        deleteButton.addActionListener(e -> deleteTask());
        completeButton.addActionListener(e -> completeTask());
        saveButton.addActionListener(e -> saveTasks());
        filterBox.addActionListener(e -> refreshTaskList());

        JPanel top = new JPanel(new BorderLayout(5, 5));
        top.add(inputPanel, BorderLayout.CENTER);
        top.add(buttonPanel, BorderLayout.SOUTH);

        add(top, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(filterPanel, BorderLayout.SOUTH);
    }

    private void addTask() {
        try {
            String title = titleField.getText().trim();
            if (title.isEmpty()) {
                showError("Please enter a task title.");
                return;
            }

            int priority = priorityBox.getSelectedIndex() + 1;
            LocalDateTime deadline = parseDeadline();

            tasks.add(new Task(title, priority, deadline));
            saveTasks();
            refreshTaskList();
            clearInputs();
        } catch (DateTimeParseException ex) {
            showError("Invalid deadline. Use dd-MM-yyyy HH:mm.");
        }
    }

    private void editTask() {
        Task selected = taskList.getSelectedValue();
        if (selected == null) {
            showError("Please select a task to edit.");
            return;
        }

        try {
            String title = titleField.getText().trim();
            if (title.isEmpty()) {
                showError("Please enter a task title.");
                return;
            }

            selected.setTitle(title);
            selected.setPriority(priorityBox.getSelectedIndex() + 1);
            selected.setDeadline(parseDeadline());

            saveTasks();
            refreshTaskList();
            clearInputs();
        } catch (DateTimeParseException ex) {
            showError("Invalid deadline. Use dd-MM-yyyy HH:mm.");
        }
    }

    private void deleteTask() {
        Task selected = taskList.getSelectedValue();
        if (selected == null) {
            showError("Please select a task to delete.");
            return;
        }

        int result = JOptionPane.showConfirmDialog(
                this, "Delete selected task?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            tasks.remove(selected);
            saveTasks();
            refreshTaskList();
        }
    }

    private void completeTask() {
        Task selected = taskList.getSelectedValue();
        if (selected == null) {
            showError("Please select a task.");
            return;
        }

        selected.setCompleted(true);
        saveTasks();
        refreshTaskList();
    }

    private LocalDateTime parseDeadline() {
        return LocalDateTime.parse(deadlineField.getText().trim(), formatter);
    }

    private void refreshTaskList() {
        listModel.clear();

        PriorityQueue<Task> queue = new PriorityQueue<>(
                Comparator.comparingInt(Task::getPriority)
                        .thenComparing(Task::getDeadline)
        );
        queue.addAll(tasks);

        String filter = (String) filterBox.getSelectedItem();

        while (!queue.isEmpty()) {
            Task task = queue.poll();
            if (matchesFilter(task, filter)) {
                listModel.addElement(task);
            }
        }
    }

    private boolean matchesFilter(Task task, String filter) {
        if ("Today's Tasks".equals(filter)) {
            return task.getDeadline().toLocalDate().equals(LocalDate.now());
        }
        if ("High Priority".equals(filter)) {
            return task.getPriority() == 1;
        }
        if ("Pending".equals(filter)) {
            return !task.isCompleted();
        }
        if ("Completed".equals(filter)) {
            return task.isCompleted();
        }
        return true;
    }

    private void checkReminders() {
        LocalDateTime now = LocalDateTime.now();
        for (Task task : tasks) {
            if (!task.isCompleted()
                    && !task.getDeadline().isAfter(now)
                    && task.getDeadline().isAfter(now.minusMinutes(1))) {
                JOptionPane.showMessageDialog(
                        this,
                        "Task deadline reached:\n" + task.getTitle(),
                        "Task Reminder",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void saveTasks() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(dataFile))) {
            out.writeObject(tasks);
        } catch (IOException ex) {
            showError("Could not save tasks: " + ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadTasks() {
        if (!dataFile.exists()) return;

        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(dataFile))) {
            List<Task> loaded = (List<Task>) in.readObject();
            tasks.clear();
            tasks.addAll(loaded);
        } catch (IOException | ClassNotFoundException ex) {
            showError("Could not load saved tasks.");
        }
    }

    private void clearInputs() {
        titleField.setText("");
        deadlineField.setText("");
        priorityBox.setSelectedIndex(0);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TaskSchedulerApp app = new TaskSchedulerApp();
            app.setVisible(true);
        });
    }
}
