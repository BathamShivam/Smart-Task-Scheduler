import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Task implements Serializable {
    private static final long serialVersionUID = 1L;
    private String title;
    private int priority; // 1 = High, 2 = Medium, 3 = Low
    private LocalDateTime deadline;
    private boolean completed;

    public Task(String title, int priority, LocalDateTime deadline) {
        this.title = title;
        this.priority = priority;
        this.deadline = deadline;
        this.completed = false;
    }

    public String getTitle() { return title; }
    public int getPriority() { return priority; }
    public LocalDateTime getDeadline() { return deadline; }
    public boolean isCompleted() { return completed; }

    public void setTitle(String title) { this.title = title; }
    public void setPriority(int priority) { this.priority = priority; }
    public void setDeadline(LocalDateTime deadline) { this.deadline = deadline; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public String getPriorityText() {
        return switch (priority) {
            case 1 -> "High";
            case 2 -> "Medium";
            default -> "Low";
        };
    }

    public String getDeadlineText() {
        return deadline.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"));
    }

    @Override
    public String toString() {
        return title + " | " + getPriorityText() + " | " + getDeadlineText()
                + (completed ? " | Completed" : "");
    }
}
