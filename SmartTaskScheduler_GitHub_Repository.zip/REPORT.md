# Smart Task Scheduler with Priority Queues

## Introduction
Smart Task Scheduler is a Java Swing desktop application designed to help users organize tasks according to urgency and deadlines. It uses a PriorityQueue so that important and urgent tasks can be displayed before lower-priority tasks.

## Abstract
The project provides a simple graphical task management system. Users can add, edit, delete, complete, and filter tasks. Each task contains a title, priority, and deadline. A PriorityQueue sorts tasks first by priority and then by deadline. The application also provides deadline reminders using Java Timer and stores tasks using Java file I/O and object serialization.

## Tools Used
- Java
- Java Swing
- PriorityQueue
- Java Collections Framework
- Java File I/O
- Java Serialization
- Java Time API
- IntelliJ IDEA / Eclipse / VS Code

## Steps Involved in Building the Project
1. Created a `Task` class containing title, priority, deadline, and completion status.
2. Created the Swing GUI for entering and displaying tasks.
3. Implemented a `PriorityQueue` with a comparator to sort tasks by priority and deadline.
4. Added Add, Edit, Delete, and Mark Complete operations.
5. Added filters for today's tasks, high-priority tasks, pending tasks, and completed tasks.
6. Implemented reminders using `javax.swing.Timer`.
7. Implemented file I/O using object serialization to save and load tasks.
8. Added a README with setup and execution instructions.
9. Tested the application by creating tasks with different priorities and deadlines.

## Conclusion
The Smart Task Scheduler demonstrates practical use of Java OOP, collections, GUI programming, file handling, and date-time APIs. The project provides a simple but useful task management solution while demonstrating how a PriorityQueue can be used to prioritize real-world tasks.
