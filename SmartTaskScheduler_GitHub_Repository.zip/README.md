# Smart Task Scheduler with Priority Queues

A Java Swing desktop application that manages tasks according to urgency and deadline.

## Features

- Add tasks with title, priority, and deadline
- Priority levels: High, Medium, Low
- Uses Java `PriorityQueue` to organize tasks
- Edit and delete tasks
- Mark tasks as completed
- Filter today's tasks, high-priority tasks, pending tasks, or completed tasks
- Deadline reminders using `javax.swing.Timer`
- Save and load tasks using Java file I/O and object serialization
- Simple desktop GUI using Java Swing

## Technologies Used

- Java
- Java Swing
- Java Collections Framework
- PriorityQueue
- File I/O
- Object Serialization
- Java Time API

## Project Structure

```text
SmartTaskScheduler/
├── src/
│   ├── Task.java
│   └── TaskSchedulerApp.java
├── README.md
└── .gitignore
```

## How to Run

### Option 1: Command Line

Open a terminal in the project folder:

```bash
javac -d out src/Task.java src/TaskSchedulerApp.java
java -cp out TaskSchedulerApp
```

### Option 2: IntelliJ IDEA / Eclipse

1. Create/import the project.
2. Add the `src` folder as the source folder.
3. Run `TaskSchedulerApp.java`.

## Deadline Format

Use:

```text
dd-MM-yyyy HH:mm
```

Example:

```text
05-10-2026 18:30
```

## How PriorityQueue Works

The application stores tasks in a `PriorityQueue`. Tasks with a higher priority are shown first:

1. High
2. Medium
3. Low

If two tasks have the same priority, the task with the earlier deadline is shown first.

## Data Storage

Tasks are saved automatically in a local file named:

```text
tasks.dat
```

This file is created when the application saves its first task.

## Future Improvements

- Export tasks to JSON
- Add recurring tasks
- Add system tray notifications
- Add calendar view
- Package as an executable JAR

## Author

Developed as a Java project demonstrating OOP, collections, GUI development, reminders, and file handling.
